package com.go2it.edu.lecture3.methods;
// Tak 3.5 Create methods that will accept the current day of the week and will:
//a. Show on console how many days of the week left till weekend
//b. Return an array with all the days left till weekend
import java.util.Calendar;
import java.util.Date;

public class AcceptCurrentDay {
    public static void main(String[] args) {
       Date currentDate = new Date();
       System.out.println("Today is " + currentDate);
    }

}
