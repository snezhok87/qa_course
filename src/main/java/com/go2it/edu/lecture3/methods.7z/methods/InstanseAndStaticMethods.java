package com.go2it.edu.lecture3.methods;

import java.util.Scanner;

public class InstanseAndStaticMethods {
    public void instanceMethod(){
        System.out.println("Hello user! Please enter your name: ");
        Scanner in = new Scanner(System.in);
        String inputFromUser = in.nextLine();
        System.out.println("Welcome, " + inputFromUser);
    }

    public static String staticMethod(String[] names) {
        String greeting = "Hello, my friend " + names[0] + " and " + names[1];
//        System.out.println("Inside static method ");
        return greeting;
    }

    public static void main(String[] args) {
        System.out.println("Before starting method was involved");
        String result = staticMethod(args);
        System.out.println(staticMethod(args));
        System.out.println("After starting method was involved");
        InstanseAndStaticMethods instanceMethod = new InstanseAndStaticMethods();
        instanceMethod.instanceMethod();
    }
}
