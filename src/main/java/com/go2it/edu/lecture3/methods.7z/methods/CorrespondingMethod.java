package com.go2it.edu.lecture3.methods;
 // Task: create a method initializeArray that will create an array, will put only (!) odd
// values inside and will return the resulting array (returns int[])

public class CorrespondingMethod {
    public static void main(String[] args) {
        int[] oddValues;
        printValues(initializedArray());
    }

    public static int[] initializedArray(int oddValues) {
        int[] oddValues = new int[100];
        oddValues[0] = 1;
        for (int i = 0; i < 100; i++) { //how to declare all odd numbers?
        }
        System.out.println("Here are the odd values: " + i);
        return oddValues;
    }

    public static void printValues(int initializedArray) {
        ;
        System.out.println(initializedArray);
    }
}










